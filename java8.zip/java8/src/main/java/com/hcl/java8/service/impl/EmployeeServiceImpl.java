package com.hcl.java8.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.java8.dto.EmployeeDto;
import com.hcl.java8.dto.EmployeeRequestDto;
import com.hcl.java8.dto.EmployeeResponseDto;
import com.hcl.java8.exception.EmployeeException;
import com.hcl.java8.model.Employee;
import com.hcl.java8.repository.EmployeeRepository;
import com.hcl.java8.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public String saveEmployee(EmployeeRequestDto employeeRequestDto) throws EmployeeException {
		log.info("saveEmployee(): called", employeeRequestDto.getEmployeeName());
		if (employeeRequestDto.getAge() < 18) {
			log.warn("Age should not be less than 18");
			throw new EmployeeException("Age should be greater than 18");
		}
		if ((("" + employeeRequestDto.getPhoneNo()).length() != 10)) {
			log.warn("Phone number length should be 10");
			throw new EmployeeException("Length of the phone number should be equal to 10");
		}

		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeRequestDto, employee);
		employeeRepository.save(employee);
		log.info("Data saved into employee table successfully");

		return "Employee added successfully";
	}

	@Override
	public List<EmployeeResponseDto> highSalary(double salary) throws EmployeeException {
		log.info("Finding the list of employees whose salary is greater than", salary);
		List<Employee> employeeList = (List<Employee>) (employeeRepository.findAll().stream()
				.filter(employee -> employee.getSalary() > salary)).collect(Collectors.toList());
		if (employeeList.isEmpty()) {
			log.warn("The employee is empty");
			throw new EmployeeException("No employees having salary greater than" + salary);
		}
		return EmployeeService.convertEmployeeListToEmployeeResponseDtoList(employeeList);
	}

	// list of employees those who have less salary
	@Override
	public List<EmployeeDto> lowSalary(double salary) throws EmployeeException {
		log.info("Finding the list of employees whose salary is less than", salary);
		List<Employee> employeeList = (List<Employee>) (employeeRepository.findAll().stream()
				.filter(employee -> employee.getSalary() < salary).collect(Collectors.toList()));
		if (employeeList.isEmpty()) {
			log.warn("The employee list is empty");
			throw new EmployeeException("No employees having salary less than" + salary);
		}
		return EmployeeService.convertEmployeeListToEmployeeDtoList(employeeList);
	}

	// Providing hike based on the salary
	@Override
	public Map<String, Double> hikeForLessSalaried(double salary, double givenHike) throws EmployeeException {
		log.info("Giving hike to the list of employees whose salary is less than", salary);
		List<Employee> employeeList = (List<Employee>) (employeeRepository.findAll().stream()
				.filter(employee -> employee.getSalary() < salary).collect(Collectors.toList()));
		if (employeeList.isEmpty()) {
			log.warn("The employee list is empty");
			throw new EmployeeException("No employees having salary less than" + salary);
		}
		Map<String, Double> map = new HashMap<>();
		employeeList.forEach(emp -> {
			emp.setSalary(emp.getSalary() + givenHike);
			map.put(emp.getEmployeeName(), emp.getSalary());
			log.info("Updating the changes on salary column");
			employeeRepository.flush();
			log.info("Changes done successfully");
		});
		return map;
	}

}
