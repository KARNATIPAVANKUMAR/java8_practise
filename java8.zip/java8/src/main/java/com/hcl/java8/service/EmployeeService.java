package com.hcl.java8.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;

import com.hcl.java8.dto.EmployeeDto;
import com.hcl.java8.dto.EmployeeRequestDto;
import com.hcl.java8.dto.EmployeeResponseDto;
import com.hcl.java8.exception.EmployeeException;
import com.hcl.java8.model.Employee;

public interface EmployeeService {

	public String saveEmployee(EmployeeRequestDto employeeRequestDto) throws EmployeeException;

	public List<EmployeeResponseDto> highSalary(double salary) throws EmployeeException ;

	public List<EmployeeDto> lowSalary(double salary) throws EmployeeException;

	public Map<String, Double> hikeForLessSalaried(double salary, double givenHike) throws EmployeeException;

	
	
	public static List<EmployeeResponseDto> convertEmployeeListToEmployeeResponseDtoList(List<Employee> employeeList) {
		List<EmployeeResponseDto> employeeResponseDtoList=new ArrayList<EmployeeResponseDto>();
		employeeList.forEach(emp->{
			EmployeeResponseDto employeeResponseDto=new EmployeeResponseDto();
			BeanUtils.copyProperties(emp,employeeResponseDto);
			employeeResponseDtoList.add(employeeResponseDto);
		});
		
		return employeeResponseDtoList;
		
	}
	
	public static List<EmployeeDto> convertEmployeeListToEmployeeDtoList(List<Employee> employeeList) {
		List<EmployeeDto> employeeDtoList=new ArrayList<EmployeeDto>();
		employeeList.forEach(emp->{
			EmployeeDto employeeResponseDto=new EmployeeDto();
			BeanUtils.copyProperties(emp,employeeResponseDto);
			employeeDtoList.add(employeeResponseDto);
		});
		
		return employeeDtoList;
		
	}



}
