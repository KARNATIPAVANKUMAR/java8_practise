package com.hcl.java8.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.java8.dto.EmployeeDto;
import com.hcl.java8.dto.EmployeeRequestDto;
import com.hcl.java8.dto.EmployeeResponseDto;
import com.hcl.java8.exception.EmployeeException;
import com.hcl.java8.service.EmployeeService;


@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService  employeeService;
	
	@PostMapping("/employees")
	public ResponseEntity<String> saveEmployee(@RequestBody EmployeeRequestDto employeeRequestDto) throws EmployeeException{
		return new ResponseEntity<String>(employeeService.saveEmployee(employeeRequestDto),HttpStatus.CREATED);
		
		
	}
	
	
	@GetMapping("/employees/higherSalary")
	public ResponseEntity<List<EmployeeResponseDto>> havingSalary(@RequestParam double salary) throws EmployeeException{
		
			
		return new ResponseEntity<List<EmployeeResponseDto>>(employeeService.highSalary(salary),HttpStatus.OK);
		
	}
	
	
	@GetMapping("/employees/lowSalary")
	public ResponseEntity<List<EmployeeDto>> lowSalary(@RequestParam double salary) throws EmployeeException{
		
		return new ResponseEntity<List<EmployeeDto>>(employeeService.lowSalary(salary),HttpStatus.OK);
		
	}
	
	
	public ResponseEntity<Map<String,Double>> hikeForLessSalaried(@RequestParam double salary,@RequestParam double givenHike) throws EmployeeException{
		return new ResponseEntity<Map<String,Double>>(employeeService.hikeForLessSalaried(salary,givenHike),HttpStatus.OK);
	}

}
