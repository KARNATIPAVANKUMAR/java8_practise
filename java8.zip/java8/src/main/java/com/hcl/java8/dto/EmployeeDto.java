package com.hcl.java8.dto;

public class EmployeeDto {

	private String employeeName;

	private String designation;

	public EmployeeDto() {

	}

	public EmployeeDto(String employeeName, String designation) {

		this.employeeName = employeeName;
		this.designation = designation;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

}
